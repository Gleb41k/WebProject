function animateAndRedirect() {
    const wrapper = document.getElementById("loginWrapper");
    wrapper.classList.remove("show");
    wrapper.classList.add("hide");

    setTimeout(() => {
        window.location.href = "index.html"; 
    }, 500);
}

/// Вход
document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const errorMessage = document.getElementById("errorMessage");

    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];

    const user = storedUsers.find(user => user.username === username && user.password === password);

    if (user) {
        localStorage.setItem("authenticated", "true");
        localStorage.setItem("username", username); 
        localStorage.setItem("currentUser", JSON.stringify(user)); 
        animateAndRedirect();
    } else {
        errorMessage.style.display = "block";
    }
});

document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const newUsername = document.getElementById("newUsername").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();

    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];


    const existingUser = storedUsers.find(user => user.username === newUsername);
    if (existingUser) {
        alert("Пользователь с таким логином уже существует.");
        return;
    }

    storedUsers.push({ username: newUsername, password: newPassword });
    localStorage.setItem("users", JSON.stringify(storedUsers)); 

    localStorage.setItem("username", newUsername);
    localStorage.setItem("authenticated", "true");
    animateAndRedirect();
});

document.getElementById("showRegister").addEventListener("click", function () {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("registerForm").style.display = "flex";
});

document.getElementById("showLogin").addEventListener("click", function () {
    document.getElementById("registerForm").style.display = "none";
    document.getElementById("loginForm").style.display = "flex";
});

document.addEventListener("DOMContentLoaded", function () {
    const wrapper = document.getElementById("loginWrapper");
    setTimeout(() => {
        wrapper.classList.add("show");
    }, 100);
});

function logout() {
    localStorage.removeItem("authenticated");
    localStorage.removeItem("currentUser");
    window.location.href = "login.html";
}

document.addEventListener("DOMContentLoaded", function () {
    const storedUsername = localStorage.getItem("username");

    if (!storedUsername) {
        const greetingEl = document.getElementById("greetingText");
        if (greetingEl) {
            greetingEl.textContent = "Введите ваш логин";
        }
    }
});
